$('.dropdown-trigger').dropdown({
    alignment: 'left',
    coverTrigger: false
});

$('#textProj').on('input', function(){
    $('#btnNewProj').prop('disabled', !this.value);
    $('#btnNewProj-min').prop('disabled', !this.value);
});

$('#textSub').on('input', function(){
    $('#btnNewSub').prop('disabled', !this.value);
    $('#btnNewSub-min').prop('disabled', !this.value);
});

