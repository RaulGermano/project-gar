
	$(document).ready(function(){
    	$('.collapsible').collapsible();
 	});

	function addItem(id) {
		if (document.getElementById(id).style.display == 'none') {
			document.getElementById(id).style.display = 'block';
		}else{
			document.getElementById(id).style.display = 'none';
		}
	}

	function lessIten(id) {
		if (document.getElementById(id).style.display == 'none') {
			document.getElementById(id).style.display = 'block';
		}else{
			document.getElementById(id).style.display = 'none';
		}
	}

  	$(document).ready(function(){
    	$('.modal').modal({
    		opacity: .7,
    		dismissible: false
    	});
	});

	$(document).ready(function(){
    	$('.sidenav').sidenav();
    });

	$(document).ready(function() {
    	$('input#input_text').characterCounter();
    });

	$(document).ready(function() {
    	$('input#input_text').characterCounter();
    });

	$(document).ready(function(){
		$('.datepicker').datepicker({
			autoClose: true,
			format: 'd / mmmm / yyyy',
			yearRange: 100,
			showDaysInNextAndPreviousMonths: true,
			showClearBtn: true,
			i18n: {
				today: 'Hoje',
				clear: 'Limpar',
				cancel: 'cancelar',
				done: 'Ok',
				nextMonth: 'Próximo mês',
				previousMonth: 'Mês anterior',
				weekdaysAbbrev: ['D',
								'S',
								'T',
								'Q',
								'Q',
								'S',
								'S'],

				weekdaysShort: ['Dom',
								'Seg',
								'Ter',
								'Qua',
								'Qui',
								'Sex',
								'Sáb'],

				weekdays: [	'Domingo',
							'Segunda-Feira',
							'Terça-Feira',
							'Quarta-Feira',
							'Quinta-Feira',
							'Sexta-Feira',
							'Sábado'],

				monthsShort: [	'Jan',
								'Fev',
								'Mar',
								'Abr',
								'Mai',
								'Jun',
								'Jul',
								'Ago',
								'Set',
								'Out',
								'Nov',
								'Dez'],

				months: [	'Janeiro',
							'Fevereiro',
							'Março',
							'Abril',
							'Maio',
							'Junho',
							'Julho',
							'Agosto',
							'Setembro',
							'Outubro',
							'Novembro',
							'Dezembro']
			}
		});
	});

	$(document).ready(function(){
    	$('select').formSelect();
  	});
	
	$(document).ready(function() {
	    $('input#input_text, textarea#textarea2').characterCounter();
	});

	$(function () {
    	$("input:file").change(function () {
    		var labe1=document.getElementById('labe1');
		    var extensoes, ext, valido,i=0;
	      	var fileInput = $(this);
	      	var maxSize = $(this).data('max-size');
	      	var testeUm=fileInput.get(0).files[0].name;
	      	console.log(fileInput.get(0).files[0].name);
	      	console.log(fileInput.get(0).files[0].size);

		    extensoes = new Array('.png','.jpeg','.jpg');

		    ext = testeUm.substring(testeUm.lastIndexOf(".")).toLowerCase();
		    valido = false;
		    
		    for(i; i<=testeUm.length; i++){
		        if(extensoes[i] == ext){
		            valido = true;
		            break;
		        }
		    }

		     if(!valido){
		     	document.getElementById("sucess").style.display="none";
		     	document.getElementById("error").style.display="block";
		     	labe1.innerHTML='Extensão "<b>'+ext+'</b>" não é aceita.';
     			document.getElementById("fileDateDois").value='';
     			document.getElementById("fileDate").value='';
		        return false;
		    }
		   
	       	ext = testeUm.substring(testeUm.lastIndexOf(".")).toLowerCase();
		    console.log(ext);

	      	if (fileInput.get(0).files.length) {
	        	var fileSize = fileInput.get(0).files[0].size; // in bytes
	        	if (fileSize > maxSize) {
	        		var fileSizeMB=parseFloat((fileSize/1024)/1024).toFixed(2);
	        		var Unidade='MB';
	        		if (fileSizeMB>1024) {
	        			fileSizeMB=parseFloat(fileSizeMB/1024).toFixed(2);
	        			Unidade='GB';
	        		}
	          		
     				labe1.innerHTML='<b>'+fileSizeMB+Unidade+'</b> Ultrapassa o limite. É permitido imagens de até <b>5MB</b>.';
     				document.getElementById("error").style.display="block";
     				document.getElementById("sucess").style.display="none";
     				document.getElementById("fileDateDois").value='';
     				document.getElementById("fileDate").value='';
	          		// alert(fileSizeMB+'MB Ultrapassa o limite. É permitido imagens de até 5 MB.');
	         		return false;
	        	}else{
     				document.getElementById("error").style.display="none";
     				document.getElementById("sucess").style.display="block";
     				labe1.innerHTML='';
	        	}
	      	}else {
	        	alert('choose file, please');
	        	return false;
	      	}
    	});
	  });
	  
	angular.module('todoApp', [])

  	.controller('TodoListController', function() {
		var todoList = this;
		todoList.todos = [
			{text:'learn AngularJS', done:true},
			{text:'build an AngularJS app', done:false}];
	
		todoList.archive = function() {
			var oldTodos = todoList.todos;
			todoList.todos = [];
			angular.forEach(oldTodos, function(todo) {
				if (!todo.done) todoList.todos.push(todo);
			});
		};
	});